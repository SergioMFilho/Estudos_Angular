import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sucesso-cadastro',
  templateUrl: './sucesso-cadastro.component.html',
  styleUrls: ['./sucesso-cadastro.component.css']
})
export class SucessoCadastroComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
